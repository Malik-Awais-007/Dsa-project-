import sys

from PyQt6.QtWidgets import QApplication

from app.ui_main import MainWindow


def main():
    application = QApplication(sys.argv)
    application.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(application.exec())


if __name__ == "__main__":
    main()
