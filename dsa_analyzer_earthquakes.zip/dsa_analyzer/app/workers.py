from PyQt6.QtCore import QThread, pyqtSignal

from .benchmark import run_benchmark


class TaskWorker(QThread):
    succeeded = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, function):
        super().__init__()
        self.function = function

    def run(self):
        try:
            result = self.function()
        except Exception as error:
            self.failed.emit(str(error))
            return
        self.succeeded.emit(result)


class BenchmarkWorker(QThread):
    algorithm_started = pyqtSignal(str)
    entry_ready = pyqtSignal(object)
    all_done = pyqtSignal()

    def __init__(self, rows, column_index):
        super().__init__()
        self.rows = rows
        self.column_index = column_index
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        run_benchmark(
            self.rows,
            self.column_index,
            self.algorithm_started.emit,
            self.entry_ready.emit,
            lambda: self._cancelled,
        )
        self.all_done.emit()
