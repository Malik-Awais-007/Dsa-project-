from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from .benchmark import select_rows
from .config import DEFAULT_TARGET
from .filters import make_id_predicate, make_predicate, operators_for
from .models import COLUMN_WIDTHS, COLUMNS, TEXT
from .scraper import ScrapeWorker, validate_source_url
from .searching import SEARCH_ALGORITHMS, parse_target, scan_filter, search_equals
from .sorting import ALGORITHM_MAP, ALGORITHMS, multi_level_sort, sort_rows
from .storage import load_earthquakes, save_earthquakes
from .table_model import EarthquakeTableModel
from .ui_dialogs import BenchmarkDialog, CompositeFilterDialog, MultiSortDialog, SearchCompareDialog
from .workers import TaskWorker

STYLE = """
QGroupBox { font-weight: bold; border: 1px solid #b9c2cc; border-radius: 6px; margin-top: 10px; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QPushButton { padding: 5px 12px; }
QLabel#metrics { color: #1f4e79; font-weight: bold; }
"""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Data Structure & Algorithm Analyzer - Earthquakes")
        self.resize(1450, 900)
        self.setStyleSheet(STYLE)
        self.model = EarthquakeTableModel()
        self.worker = None
        self.task = None
        self.pending_callback = None
        self.busy = False
        self.scraping = False
        self.paused = False
        self.last_sort_column = -1
        self.last_descending = False
        self.build_ui()
        self.load_existing()
        self.update_controls()

    def build_ui(self):
        central = QWidget()
        layout = QVBoxLayout(central)
        layout.addWidget(self.build_scrape_group())
        layout.addWidget(self.build_table(), 1)
        self.operations = QWidget()
        operations_layout = QHBoxLayout(self.operations)
        operations_layout.setContentsMargins(0, 0, 0, 0)
        operations_layout.addWidget(self.build_sort_group(), 1)
        operations_layout.addWidget(self.build_search_group(), 1)
        layout.addWidget(self.operations)
        self.setCentralWidget(central)
        self.count_label = QLabel()
        self.statusBar().addPermanentWidget(self.count_label)
        self.model.modelReset.connect(self.update_counts)
        self.model.rowsInserted.connect(self.update_counts)
        self.refresh_sort_algorithms()
        self.refresh_search_controls()

    def build_scrape_group(self):
        group = QGroupBox("Data Collection (USGS Earthquakes)")
        grid = QGridLayout(group)
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText(
            "Optional: paste a USGS query URL, e.g. https://earthquake.usgs.gov/fdsnws/event/1/query?starttime=2020-01-01&minmagnitude=5  (empty = automatic year-by-year collection)"
        )
        self.target_input = QSpinBox()
        self.target_input.setRange(1000, 200000)
        self.target_input.setSingleStep(1000)
        self.target_input.setValue(DEFAULT_TARGET)
        self.start_button = QPushButton("Start")
        self.pause_button = QPushButton("Pause")
        self.resume_button = QPushButton("Resume")
        self.stop_button = QPushButton("Stop")
        self.start_button.clicked.connect(self.start_scraping)
        self.pause_button.clicked.connect(self.pause_scraping)
        self.resume_button.clicked.connect(self.resume_scraping)
        self.stop_button.clicked.connect(self.stop_scraping)
        self.progress = QProgressBar()
        self.progress.setFormat("%v / %m records")
        self.status_label = QLabel("Ready")
        grid.addWidget(QLabel("Source URL"), 0, 0)
        grid.addWidget(self.url_input, 0, 1)
        grid.addWidget(QLabel("Target records"), 0, 2)
        grid.addWidget(self.target_input, 0, 3)
        grid.addWidget(self.start_button, 0, 4)
        grid.addWidget(self.pause_button, 0, 5)
        grid.addWidget(self.resume_button, 0, 6)
        grid.addWidget(self.stop_button, 0, 7)
        grid.addWidget(self.progress, 1, 0, 1, 7)
        grid.addWidget(self.status_label, 1, 7)
        grid.setColumnStretch(1, 1)
        return group

    def build_table(self):
        self.table = QTableView()
        self.table.setModel(self.model)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)
        header = self.table.horizontalHeader()
        header.setSectionsClickable(True)
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        header.sectionClicked.connect(self.on_header_clicked)
        for index, width in enumerate(COLUMN_WIDTHS):
            self.table.setColumnWidth(index, width)
        self.table.verticalHeader().setDefaultSectionSize(24)
        return self.table

    def build_sort_group(self):
        group = QGroupBox("Sorting")
        grid = QGridLayout(group)
        self.sort_column = QComboBox()
        for index, column in enumerate(COLUMNS):
            self.sort_column.addItem(column.title, index)
        self.sort_column.setCurrentIndex(1)
        self.sort_algorithm = QComboBox()
        self.sort_order = QComboBox()
        self.sort_order.addItems(["Ascending", "Descending"])
        self.sort_scope = QComboBox()
        self.sort_scope.addItems(["Full dataset", "Filtered results only"])
        self.algorithm_info = QLabel()
        self.sort_button = QPushButton("Sort")
        self.multi_sort_button = QPushButton("Multi-Level Sort")
        self.benchmark_size = QComboBox()
        for label, size in (("1,000 rows", 1000), ("5,000 rows", 5000), ("10,000 rows", 10000), ("All rows", 0)):
            self.benchmark_size.addItem(label, size)
        self.benchmark_size.setCurrentIndex(1)
        self.benchmark_button = QPushButton("Benchmark All Algorithms")
        self.sort_result_label = QLabel("No sort performed yet")
        self.sort_result_label.setObjectName("metrics")
        self.sort_result_label.setWordWrap(True)
        self.sort_column.currentIndexChanged.connect(self.refresh_sort_algorithms)
        self.sort_algorithm.currentIndexChanged.connect(self.update_algorithm_info)
        self.sort_button.clicked.connect(self.start_sort)
        self.multi_sort_button.clicked.connect(self.start_multi_sort)
        self.benchmark_button.clicked.connect(self.start_benchmark)
        grid.addWidget(QLabel("Column"), 0, 0)
        grid.addWidget(self.sort_column, 0, 1)
        grid.addWidget(QLabel("Order"), 0, 2)
        grid.addWidget(self.sort_order, 0, 3)
        grid.addWidget(QLabel("Algorithm"), 1, 0)
        grid.addWidget(self.sort_algorithm, 1, 1, 1, 3)
        grid.addWidget(QLabel("Scope"), 2, 0)
        grid.addWidget(self.sort_scope, 2, 1)
        grid.addWidget(self.algorithm_info, 2, 2, 1, 2)
        grid.addWidget(self.sort_button, 3, 0)
        grid.addWidget(self.multi_sort_button, 3, 1)
        grid.addWidget(self.benchmark_size, 3, 2)
        grid.addWidget(self.benchmark_button, 3, 3)
        grid.addWidget(self.sort_result_label, 4, 0, 1, 4)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        return group

    def build_search_group(self):
        group = QGroupBox("Searching and Filtering")
        grid = QGridLayout(group)
        self.search_column = QComboBox()
        for index, column in enumerate(COLUMNS):
            self.search_column.addItem(column.title, index)
        self.search_column.setCurrentIndex(1)
        self.search_operator = QComboBox()
        self.search_value = QLineEdit()
        self.search_value.setPlaceholderText("Value to search")
        self.search_algorithm = QComboBox()
        self.search_hint = QLabel()
        self.search_button = QPushButton("Search")
        self.compare_search_button = QPushButton("Compare All Search Algorithms")
        self.advanced_button = QPushButton("Advanced Filter (AND / OR / NOT)")
        self.clear_button = QPushButton("Clear Filter")
        self.search_result_label = QLabel("No search performed yet")
        self.search_result_label.setObjectName("metrics")
        self.search_result_label.setWordWrap(True)
        self.search_column.currentIndexChanged.connect(self.refresh_search_controls)
        self.search_operator.currentIndexChanged.connect(self.update_search_hint)
        self.search_value.returnPressed.connect(self.start_search)
        self.search_button.clicked.connect(self.start_search)
        self.compare_search_button.clicked.connect(self.compare_searches)
        self.advanced_button.clicked.connect(self.open_composite_filter)
        self.clear_button.clicked.connect(self.clear_filter)
        grid.addWidget(QLabel("Column"), 0, 0)
        grid.addWidget(self.search_column, 0, 1)
        grid.addWidget(QLabel("Operator"), 0, 2)
        grid.addWidget(self.search_operator, 0, 3)
        grid.addWidget(QLabel("Value"), 1, 0)
        grid.addWidget(self.search_value, 1, 1, 1, 3)
        grid.addWidget(QLabel("Algorithm"), 2, 0)
        grid.addWidget(self.search_algorithm, 2, 1, 1, 3)
        grid.addWidget(self.search_hint, 3, 0, 1, 4)
        grid.addWidget(self.search_button, 4, 0)
        grid.addWidget(self.compare_search_button, 4, 1)
        grid.addWidget(self.advanced_button, 4, 2, 1, 2)
        grid.addWidget(self.clear_button, 5, 0)
        grid.addWidget(self.search_result_label, 6, 0, 1, 4)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        return group

    def refresh_sort_algorithms(self):
        kind = COLUMNS[self.sort_column.currentData()].kind
        current = self.sort_algorithm.currentData()
        self.sort_algorithm.blockSignals(True)
        self.sort_algorithm.clear()
        for algorithm in ALGORITHMS:
            if algorithm.numeric_only and kind == TEXT:
                continue
            self.sort_algorithm.addItem(algorithm.label, algorithm.name)
        index = self.sort_algorithm.findData(current if current else "Merge Sort")
        self.sort_algorithm.setCurrentIndex(index if index >= 0 else self.sort_algorithm.findData("Merge Sort"))
        self.sort_algorithm.blockSignals(False)
        self.update_algorithm_info()

    def update_algorithm_info(self):
        name = self.sort_algorithm.currentData()
        if name is None:
            return
        algorithm = ALGORITHM_MAP[name]
        self.algorithm_info.setText(f"Time: {algorithm.complexity}  |  {'Stable' if algorithm.stable else 'Unstable'}")

    def refresh_search_controls(self):
        kind = COLUMNS[self.search_column.currentData()].kind
        self.search_operator.blockSignals(True)
        self.search_operator.clear()
        self.search_operator.addItems(operators_for(kind))
        self.search_operator.setCurrentText("contains" if kind == TEXT else "equals")
        self.search_operator.blockSignals(False)
        current = self.search_algorithm.currentData()
        self.search_algorithm.clear()
        for algorithm in SEARCH_ALGORITHMS:
            if algorithm.numeric_only and kind == TEXT:
                continue
            self.search_algorithm.addItem(algorithm.label, algorithm.name)
        index = self.search_algorithm.findData(current)
        self.search_algorithm.setCurrentIndex(index if index >= 0 else 0)
        self.update_search_hint()

    def update_search_hint(self):
        is_equals = self.search_operator.currentText() == "equals"
        self.search_algorithm.setEnabled(is_equals and not self.busy)
        if is_equals:
            self.search_hint.setText("The selected algorithm is used for the Equals operator.")
        else:
            self.search_hint.setText("This operator uses a linear scan over all records.")

    def update_controls(self):
        operations_enabled = not self.busy and (not self.scraping or self.paused)
        self.operations.setEnabled(operations_enabled)
        self.start_button.setEnabled(not self.scraping and not self.busy)
        self.url_input.setEnabled(not self.scraping)
        self.target_input.setEnabled(not self.scraping)
        self.pause_button.setEnabled(self.scraping and not self.paused)
        self.resume_button.setEnabled(self.scraping and self.paused)
        self.stop_button.setEnabled(self.scraping)
        self.update_search_hint()

    def update_counts(self, *args):
        self.count_label.setText(f"Showing {len(self.model.view_rows):,} of {len(self.model.all_rows):,} records")

    def load_existing(self):
        rows = load_earthquakes()
        self.model.set_rows(rows)
        self.progress.setMaximum(self.target_input.value())
        self.progress.setValue(min(len(rows), self.target_input.value()))
        if rows:
            self.status_label.setText(f"Loaded {len(rows):,} saved records")
        self.update_counts()

    def warn(self, message):
        QMessageBox.warning(self, "Notice", message)

    def start_scraping(self):
        url = self.url_input.text().strip()
        if url:
            try:
                validate_source_url(url)
            except ValueError as error:
                self.warn(str(error))
                return
        target = self.target_input.value()
        existing = {row[0] for row in self.model.all_rows}
        if len(existing) >= target:
            self.warn("The dataset already contains the target number of records. Increase the target to collect more.")
            return
        self.worker = ScrapeWorker(existing, target, url)
        self.worker.batch.connect(self.on_batch)
        self.worker.status.connect(self.status_label.setText)
        self.worker.completed.connect(self.on_scrape_completed)
        self.progress.setMaximum(target)
        self.progress.setValue(len(existing))
        self.scraping = True
        self.paused = False
        self.status_label.setText("Starting...")
        self.update_controls()
        self.worker.start()

    def pause_scraping(self):
        self.worker.pause()
        self.paused = True
        self.status_label.setText("Paused")
        self.update_controls()

    def resume_scraping(self):
        self.worker.resume()
        self.paused = False
        self.status_label.setText("Resuming...")
        self.update_controls()

    def stop_scraping(self):
        self.worker.stop()
        self.stop_button.setEnabled(False)
        self.pause_button.setEnabled(False)
        self.resume_button.setEnabled(False)
        self.status_label.setText("Stopping...")

    def on_batch(self, rows):
        self.model.append_rows(rows)
        self.progress.setValue(min(len(self.model.all_rows), self.progress.maximum()))

    def on_scrape_completed(self, reason):
        save_earthquakes(self.model.all_rows)
        self.scraping = False
        self.paused = False
        self.progress.setValue(min(len(self.model.all_rows), self.progress.maximum()))
        self.status_label.setText(f"{reason} - {len(self.model.all_rows):,} records saved")
        self.update_controls()

    def run_task(self, function, on_success, message):
        self.busy = True
        self.pending_callback = on_success
        self.update_controls()
        self.statusBar().showMessage(message)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        self.task = TaskWorker(function)
        self.task.succeeded.connect(self.on_task_succeeded)
        self.task.failed.connect(self.on_task_failed)
        self.task.start()

    def finish_task(self):
        QApplication.restoreOverrideCursor()
        self.busy = False
        self.statusBar().clearMessage()
        self.update_controls()

    def on_task_succeeded(self, result):
        callback = self.pending_callback
        self.pending_callback = None
        self.finish_task()
        callback(result)

    def on_task_failed(self, message):
        self.pending_callback = None
        self.finish_task()
        self.warn(message)

    def sort_source(self):
        full_scope = self.sort_scope.currentIndex() == 0
        rows = list(self.model.all_rows if full_scope else self.model.view_rows)
        return full_scope, rows

    def on_header_clicked(self, section):
        if not self.operations.isEnabled():
            return
        if section == self.last_sort_column:
            descending = not self.last_descending
        else:
            descending = False
        self.sort_column.setCurrentIndex(section)
        self.sort_order.setCurrentIndex(1 if descending else 0)
        self.start_sort()

    def start_sort(self):
        column_index = self.sort_column.currentData()
        algorithm_name = self.sort_algorithm.currentData()
        descending = self.sort_order.currentIndex() == 1
        full_scope, rows = self.sort_source()
        if not rows:
            self.warn("There are no records to sort.")
            return

        def job():
            return sort_rows(algorithm_name, rows, column_index, descending)

        def done(result):
            self.apply_sort(result, full_scope, f"{COLUMNS[column_index].title} ({'descending' if descending else 'ascending'})")
            self.last_sort_column = column_index
            self.last_descending = descending
            indicator = Qt.SortOrder.DescendingOrder if descending else Qt.SortOrder.AscendingOrder
            self.table.horizontalHeader().setSortIndicatorShown(True)
            self.table.horizontalHeader().setSortIndicator(column_index, indicator)

        self.run_task(job, done, f"Sorting {len(rows):,} records with {algorithm_name}...")

    def start_multi_sort(self):
        dialog = MultiSortDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        levels = dialog.levels()
        algorithm_name = dialog.algorithm_name()
        full_scope, rows = self.sort_source()
        if not rows:
            self.warn("There are no records to sort.")
            return
        description = ", ".join(
            f"{COLUMNS[index].title} ({'desc' if descending else 'asc'})" for index, descending in levels
        )

        def job():
            return multi_level_sort(algorithm_name, rows, levels)

        def done(result):
            self.apply_sort(result, full_scope, f"Multi-level: {description}")

        self.run_task(job, done, f"Multi-level sorting with {algorithm_name}...")

    def apply_sort(self, result, full_scope, description):
        if full_scope:
            self.model.replace_all_rows(result.rows)
        else:
            self.model.replace_view_rows(result.rows)
        scope = "full dataset" if full_scope else "filtered results"
        self.sort_result_label.setText(
            f"{result.algorithm} on {description} ({scope}): {result.elapsed_ms:,.3f} ms  |  "
            f"{result.comparisons:,} comparisons  |  {result.swaps:,} swaps/moves"
        )

    def start_benchmark(self):
        column_index = self.sort_column.currentData()
        _, rows = self.sort_source()
        if not rows:
            self.warn("There are no records to benchmark.")
            return
        sample = select_rows(rows, self.benchmark_size.currentData())
        dialog = BenchmarkDialog(self, sample, column_index)
        dialog.exec()

    def start_search(self):
        column_index = self.search_column.currentData()
        kind = COLUMNS[column_index].kind
        operator = self.search_operator.currentText()
        text = self.search_value.text()
        rows = list(self.model.all_rows)
        if not rows:
            self.warn("There are no records to search.")
            return
        try:
            if operator == "equals":
                target = parse_target(kind, text)
                algorithm_name = self.search_algorithm.currentData()

                def job():
                    return search_equals(algorithm_name, rows, column_index, kind, target)

                label = algorithm_name
            else:
                predicate = make_predicate(column_index, kind, operator, text)

                def job():
                    return scan_filter(rows, predicate)

                label = "Linear Scan"
        except ValueError as error:
            self.warn(str(error))
            return
        self.run_task(job, lambda result: self.apply_search(result, label), f"Searching with {label}...")

    def apply_search(self, result, label):
        self.model.apply_filter(make_id_predicate(result.rows))
        self.search_result_label.setText(
            f"{label}: {len(result.rows):,} matches  |  {result.elapsed_ms:,.3f} ms  |  {result.comparisons:,} comparisons"
        )

    def compare_searches(self):
        column_index = self.search_column.currentData()
        kind = COLUMNS[column_index].kind
        try:
            target = parse_target(kind, self.search_value.text())
        except ValueError as error:
            self.warn(str(error))
            return
        if not self.model.all_rows:
            self.warn("There are no records to search.")
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            dialog = SearchCompareDialog(self, list(self.model.all_rows), column_index, target)
        finally:
            QApplication.restoreOverrideCursor()
        dialog.exec()

    def open_composite_filter(self):
        dialog = CompositeFilterDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        predicate = dialog.predicate
        rows = list(self.model.all_rows)

        def job():
            return scan_filter(rows, predicate)

        self.run_task(job, lambda result: self.apply_search(result, "Composite filter"), "Applying composite filter...")

    def clear_filter(self):
        self.model.apply_filter(None)
        self.search_result_label.setText("Filter cleared")

    def closeEvent(self, event):
        if self.worker is not None and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait(8000)
        if self.model.all_rows:
            save_earthquakes(self.model.all_rows)
        super().closeEvent(event)
