from dataclasses import dataclass

TEXT = "text"
INT = "int"
FLOAT = "float"


@dataclass(frozen=True)
class Column:
    name: str
    title: str
    kind: str

    @property
    def numeric(self):
        return self.kind != TEXT


COLUMNS = [
    Column("key", "Earthquake ID", TEXT),
    Column("place", "Location", TEXT),
    Column("region", "Region", TEXT),
    Column("year", "Year", INT),
    Column("magnitude", "Magnitude", FLOAT),
    Column("depth", "Depth (km)", FLOAT),
    Column("significance", "Significance", INT),
    Column("felt", "Felt Reports", INT),
    Column("stations", "Stations", INT),
    Column("mag_type", "Magnitude Type", TEXT),
    Column("network", "Network", TEXT),
]

COLUMN_WIDTHS = [120, 300, 170, 70, 90, 90, 100, 100, 80, 120, 80]


def parse_value(kind, raw):
    if kind == INT:
        return int(float(raw))
    if kind == FLOAT:
        return float(raw)
    return raw


def parse_number(kind, raw):
    text = raw.strip()
    if not text:
        raise ValueError("Please enter a value")
    try:
        number = float(text)
    except ValueError:
        raise ValueError(f"'{text}' is not a valid number")
    if kind == INT:
        return int(number) if number == int(number) else number
    return number
