from dataclasses import dataclass
from time import perf_counter
from typing import Callable

from .models import COLUMNS, FLOAT, TEXT

MAX_COUNTING_RANGE = 2_000_000


def bubble_sort(items):
    size = len(items)
    comparisons = swaps = 0
    for end in range(size - 1, 0, -1):
        swapped = False
        for j in range(end):
            comparisons += 1
            if items[j + 1][0] < items[j][0]:
                items[j], items[j + 1] = items[j + 1], items[j]
                swaps += 1
                swapped = True
        if not swapped:
            break
    return comparisons, swaps


def selection_sort(items):
    size = len(items)
    comparisons = swaps = 0
    for i in range(size - 1):
        smallest = i
        for j in range(i + 1, size):
            comparisons += 1
            if items[j][0] < items[smallest][0]:
                smallest = j
        if smallest != i:
            items[i], items[smallest] = items[smallest], items[i]
            swaps += 1
    return comparisons, swaps


def insertion_sort(items):
    comparisons = swaps = 0
    for i in range(1, len(items)):
        current = items[i]
        j = i - 1
        while j >= 0:
            comparisons += 1
            if current[0] < items[j][0]:
                items[j + 1] = items[j]
                swaps += 1
                j -= 1
            else:
                break
        items[j + 1] = current
    return comparisons, swaps


def merge_sort(items):
    size = len(items)
    comparisons = moves = 0
    source = items
    target = [None] * size
    width = 1
    while width < size:
        for low in range(0, size, 2 * width):
            middle = min(low + width, size)
            high = min(low + 2 * width, size)
            left, right, position = low, middle, low
            while left < middle and right < high:
                comparisons += 1
                if source[right][0] < source[left][0]:
                    target[position] = source[right]
                    right += 1
                else:
                    target[position] = source[left]
                    left += 1
                position += 1
                moves += 1
            while left < middle:
                target[position] = source[left]
                left += 1
                position += 1
                moves += 1
            while right < high:
                target[position] = source[right]
                right += 1
                position += 1
                moves += 1
        source, target = target, source
        width *= 2
    if source is not items:
        items[:] = source
    return comparisons, moves


def quick_sort(items):
    comparisons = swaps = 0
    stack = [(0, len(items) - 1)]
    while stack:
        low, high = stack.pop()
        if low >= high:
            continue
        pivot = items[(low + high) // 2][0]
        less, index, greater = low, low, high
        while index <= greater:
            comparisons += 1
            if items[index][0] < pivot:
                items[less], items[index] = items[index], items[less]
                swaps += 1
                less += 1
                index += 1
            else:
                comparisons += 1
                if items[index][0] > pivot:
                    items[index], items[greater] = items[greater], items[index]
                    swaps += 1
                    greater -= 1
                else:
                    index += 1
        stack.append((low, less - 1))
        stack.append((greater + 1, high))
    return comparisons, swaps


def heap_sort(items):
    size = len(items)
    comparisons = swaps = 0

    def sift_down(root, end):
        nonlocal comparisons, swaps
        while True:
            child = 2 * root + 1
            if child > end:
                return
            if child + 1 <= end:
                comparisons += 1
                if items[child][0] < items[child + 1][0]:
                    child += 1
            comparisons += 1
            if items[root][0] < items[child][0]:
                items[root], items[child] = items[child], items[root]
                swaps += 1
                root = child
            else:
                return

    for start in range(size // 2 - 1, -1, -1):
        sift_down(start, size - 1)
    for end in range(size - 1, 0, -1):
        items[0], items[end] = items[end], items[0]
        swaps += 1
        sift_down(0, end - 1)
    return comparisons, swaps


def shell_sort(items):
    size = len(items)
    comparisons = swaps = 0
    gap = size // 2
    while gap > 0:
        for i in range(gap, size):
            current = items[i]
            j = i
            while j >= gap:
                comparisons += 1
                if current[0] < items[j - gap][0]:
                    items[j] = items[j - gap]
                    swaps += 1
                    j -= gap
                else:
                    break
            items[j] = current
        gap //= 2
    return comparisons, swaps


def counting_sort(items):
    if not items:
        return 0, 0
    smallest = min(item[0] for item in items)
    largest = max(item[0] for item in items)
    span = largest - smallest + 1
    if span > MAX_COUNTING_RANGE:
        raise ValueError("Value range is too large for Counting Sort on this column")
    counts = [0] * span
    for item in items:
        counts[item[0] - smallest] += 1
    for i in range(1, span):
        counts[i] += counts[i - 1]
    output = [None] * len(items)
    moves = 0
    for item in reversed(items):
        slot = item[0] - smallest
        counts[slot] -= 1
        output[counts[slot]] = item
        moves += 1
    items[:] = output
    return 0, moves


def radix_sort(items):
    if not items:
        return 0, 0
    smallest = min(item[0] for item in items)
    largest = max(item[0] for item in items) - smallest
    moves = 0
    place = 1
    while largest // place > 0:
        buckets = [[] for _ in range(10)]
        for item in items:
            buckets[((item[0] - smallest) // place) % 10].append(item)
            moves += 1
        items[:] = [item for bucket in buckets for item in bucket]
        place *= 10
    return 0, moves


def comb_sort(items):
    size = len(items)
    comparisons = swaps = 0
    gap = size
    finished = False
    while not finished:
        gap = int(gap / 1.3)
        if gap <= 1:
            gap = 1
            finished = True
        for i in range(size - gap):
            comparisons += 1
            if items[i + gap][0] < items[i][0]:
                items[i], items[i + gap] = items[i + gap], items[i]
                swaps += 1
                finished = False
    return comparisons, swaps


def cocktail_sort(items):
    comparisons = swaps = 0
    start, end = 0, len(items) - 1
    while start < end:
        swapped = False
        for i in range(start, end):
            comparisons += 1
            if items[i + 1][0] < items[i][0]:
                items[i], items[i + 1] = items[i + 1], items[i]
                swaps += 1
                swapped = True
        if not swapped:
            break
        end -= 1
        swapped = False
        for i in range(end - 1, start - 1, -1):
            comparisons += 1
            if items[i + 1][0] < items[i][0]:
                items[i], items[i + 1] = items[i + 1], items[i]
                swaps += 1
                swapped = True
        if not swapped:
            break
        start += 1
    return comparisons, swaps


def gnome_sort(items):
    size = len(items)
    comparisons = swaps = 0
    position = 1
    while position < size:
        comparisons += 1
        if not items[position][0] < items[position - 1][0]:
            position += 1
        else:
            items[position], items[position - 1] = items[position - 1], items[position]
            swaps += 1
            position = position - 1 if position > 1 else 1
    return comparisons, swaps


@dataclass(frozen=True)
class SortAlgorithm:
    name: str
    function: Callable
    complexity: str
    stable: bool
    numeric_only: bool = False

    @property
    def label(self):
        stability = "Stable" if self.stable else "Unstable"
        return f"{self.name}  |  {self.complexity}  |  {stability}"


ALGORITHMS = [
    SortAlgorithm("Bubble Sort", bubble_sort, "O(n²)", True),
    SortAlgorithm("Selection Sort", selection_sort, "O(n²)", False),
    SortAlgorithm("Insertion Sort", insertion_sort, "O(n²)", True),
    SortAlgorithm("Merge Sort", merge_sort, "O(n log n)", True),
    SortAlgorithm("Quick Sort", quick_sort, "O(n log n) avg, O(n²) worst", False),
    SortAlgorithm("Heap Sort", heap_sort, "O(n log n)", False),
    SortAlgorithm("Shell Sort", shell_sort, "O(n²) worst", False),
    SortAlgorithm("Counting Sort", counting_sort, "O(n + k)", True, True),
    SortAlgorithm("Radix Sort", radix_sort, "O(d · (n + k))", True, True),
    SortAlgorithm("Comb Sort", comb_sort, "O(n²) worst", False),
    SortAlgorithm("Cocktail Shaker Sort", cocktail_sort, "O(n²)", True),
    SortAlgorithm("Gnome Sort", gnome_sort, "O(n²)", True),
]

ALGORITHM_MAP = {algorithm.name: algorithm for algorithm in ALGORITHMS}
MULTI_LEVEL_ALGORITHMS = [a.name for a in ALGORITHMS if a.stable and not a.numeric_only]


@dataclass
class SortResult:
    rows: list
    comparisons: int
    swaps: int
    elapsed_ms: float
    algorithm: str


def build_pairs(rows, column_index, integer=False):
    kind = COLUMNS[column_index].kind
    if kind == TEXT:
        return [(row[column_index].casefold(), row) for row in rows]
    if integer:
        scale = 100 if kind == FLOAT else 1
        return [(int(round(row[column_index] * scale)), row) for row in rows]
    return [(row[column_index], row) for row in rows]


def sorted_pairs(rows, column_index):
    pairs = build_pairs(rows, column_index)
    merge_sort(pairs)
    return pairs


def sort_rows(algorithm_name, rows, column_index, descending=False):
    algorithm = ALGORITHM_MAP[algorithm_name]
    if algorithm.numeric_only and COLUMNS[column_index].kind == TEXT:
        raise ValueError(f"{algorithm.name} works only on numeric columns")
    pairs = build_pairs(rows, column_index, integer=algorithm.numeric_only)
    if descending:
        pairs.reverse()
    started = perf_counter()
    comparisons, swaps = algorithm.function(pairs)
    elapsed_ms = (perf_counter() - started) * 1000
    if descending:
        pairs.reverse()
    return SortResult([pair[1] for pair in pairs], comparisons, swaps, elapsed_ms, algorithm.name)


def multi_level_sort(algorithm_name, rows, levels):
    current = list(rows)
    comparisons = swaps = 0
    elapsed_ms = 0.0
    for column_index, descending in reversed(levels):
        result = sort_rows(algorithm_name, current, column_index, descending)
        current = result.rows
        comparisons += result.comparisons
        swaps += result.swaps
        elapsed_ms += result.elapsed_ms
    return SortResult(current, comparisons, swaps, elapsed_ms, algorithm_name)
