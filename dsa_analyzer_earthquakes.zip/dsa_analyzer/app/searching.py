import math
from dataclasses import dataclass
from time import perf_counter
from typing import Callable

from .models import TEXT, parse_number
from .sorting import build_pairs, sorted_pairs


@dataclass
class SearchResult:
    rows: list
    comparisons: int
    elapsed_ms: float


def parse_target(kind, raw):
    if kind == TEXT:
        value = raw.strip().casefold()
        if not value:
            raise ValueError("Please enter a value")
        return value
    return parse_number(kind, raw)


def binary_range(keys, target, low, high):
    comparisons = 0
    while low <= high:
        middle = (low + high) // 2
        comparisons += 1
        if keys[middle] == target:
            return middle, comparisons
        comparisons += 1
        if keys[middle] < target:
            low = middle + 1
        else:
            high = middle - 1
    return -1, comparisons


def binary_search(keys, target):
    return binary_range(keys, target, 0, len(keys) - 1)


def jump_search(keys, target):
    size = len(keys)
    if size == 0:
        return -1, 0
    comparisons = 0
    step = max(1, int(math.sqrt(size)))
    previous, block_end = 0, step
    while previous < size:
        edge = min(block_end, size) - 1
        comparisons += 1
        if keys[edge] >= target:
            break
        previous = block_end
        block_end += step
    else:
        return -1, comparisons
    for index in range(previous, min(block_end, size)):
        comparisons += 1
        if keys[index] == target:
            return index, comparisons
    return -1, comparisons


def exponential_search(keys, target):
    size = len(keys)
    if size == 0:
        return -1, 0
    comparisons = 1
    if keys[0] == target:
        return 0, comparisons
    bound = 1
    while bound < size:
        comparisons += 1
        if keys[bound] > target:
            break
        bound *= 2
    index, extra = binary_range(keys, target, bound // 2, min(bound, size - 1))
    return index, comparisons + extra


def interpolation_search(keys, target):
    low, high = 0, len(keys) - 1
    comparisons = 0
    while low <= high and keys[low] <= target <= keys[high]:
        comparisons += 1
        if keys[low] == keys[high]:
            return (low if keys[low] == target else -1), comparisons
        position = low + int((target - keys[low]) * (high - low) / (keys[high] - keys[low]))
        comparisons += 1
        if keys[position] == target:
            return position, comparisons
        comparisons += 1
        if keys[position] < target:
            low = position + 1
        else:
            high = position - 1
    return -1, comparisons


def linear_collect(keys, target):
    comparisons = 0
    positions = []
    for index, key in enumerate(keys):
        comparisons += 1
        if key == target:
            positions.append(index)
    return positions, comparisons


def expand_matches(keys, index, target):
    left = right = index
    comparisons = 0
    while left > 0:
        comparisons += 1
        if keys[left - 1] != target:
            break
        left -= 1
    while right < len(keys) - 1:
        comparisons += 1
        if keys[right + 1] != target:
            break
        right += 1
    return left, right, comparisons


@dataclass(frozen=True)
class SearchAlgorithm:
    name: str
    function: Callable
    complexity: str
    needs_sorted: bool
    numeric_only: bool = False

    @property
    def label(self):
        return f"{self.name}  |  {self.complexity}"


SEARCH_ALGORITHMS = [
    SearchAlgorithm("Linear Search", linear_collect, "O(n)", False),
    SearchAlgorithm("Binary Search", binary_search, "O(log n)", True),
    SearchAlgorithm("Jump Search", jump_search, "O(√n)", True),
    SearchAlgorithm("Exponential Search", exponential_search, "O(log n)", True),
    SearchAlgorithm("Interpolation Search", interpolation_search, "O(log log n) avg", True, True),
]

SEARCH_MAP = {algorithm.name: algorithm for algorithm in SEARCH_ALGORITHMS}


def search_equals(algorithm_name, rows, column_index, kind, target):
    algorithm = SEARCH_MAP[algorithm_name]
    if algorithm.numeric_only and kind == TEXT:
        raise ValueError(f"{algorithm.name} works only on numeric columns")
    if not algorithm.needs_sorted:
        keys = [pair[0] for pair in build_pairs(rows, column_index)]
        started = perf_counter()
        positions, comparisons = algorithm.function(keys, target)
        elapsed = (perf_counter() - started) * 1000
        return SearchResult([rows[position] for position in positions], comparisons, elapsed)
    pairs = sorted_pairs(rows, column_index)
    keys = [pair[0] for pair in pairs]
    started = perf_counter()
    index, comparisons = algorithm.function(keys, target)
    matched = []
    if index >= 0:
        left, right, extra = expand_matches(keys, index, target)
        comparisons += extra
        matched = [pairs[position][1] for position in range(left, right + 1)]
    elapsed = (perf_counter() - started) * 1000
    return SearchResult(matched, comparisons, elapsed)


def scan_filter(rows, predicate):
    started = perf_counter()
    matched = [row for row in rows if predicate(row)]
    elapsed = (perf_counter() - started) * 1000
    return SearchResult(matched, len(rows), elapsed)
