from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CSV_PATH = DATA_DIR / "earthquakes.csv"

DEFAULT_TARGET = 15000
API_URL = "https://earthquake.usgs.gov/fdsnws/event/1/query"
USER_AGENT = "CS200-DSA-Analyzer/1.0 (university coursework project)"
PAGE_SIZE = 500
PAGES_PER_YEAR = 14
PAGES_PER_CUSTOM_URL = 40
MIN_MAGNITUDE = 4.5
REQUEST_DELAY = 0.4
REQUEST_TIMEOUT = 40
MAX_CONSECUTIVE_FAILURES = 3

YEARS = list(range(2026, 1999, -1))
