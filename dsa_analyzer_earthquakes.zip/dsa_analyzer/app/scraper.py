import threading
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qsl, urlparse

import requests
from PyQt6.QtCore import QThread, pyqtSignal

from .config import (
    API_URL,
    MAX_CONSECUTIVE_FAILURES,
    MIN_MAGNITUDE,
    PAGE_SIZE,
    PAGES_PER_CUSTOM_URL,
    PAGES_PER_YEAR,
    REQUEST_DELAY,
    REQUEST_TIMEOUT,
    USER_AGENT,
    YEARS,
)

EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def validate_source_url(url):
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    if parsed.scheme not in ("http", "https") or host != "earthquake.usgs.gov":
        raise ValueError("Only earthquake.usgs.gov query URLs are supported")
    if "/fdsnws/event/1/query" not in parsed.path:
        raise ValueError("Use a USGS event query URL, for example https://earthquake.usgs.gov/fdsnws/event/1/query?starttime=2020-01-01&minmagnitude=5")
    params = dict(parse_qsl(parsed.query))
    for ignored in ("format", "limit", "offset", "orderby"):
        params.pop(ignored, None)
    if not params:
        raise ValueError("The query URL has no filters, for example ?starttime=2020-01-01&minmagnitude=5")
    return params


def first_text(value, default):
    if isinstance(value, list) and value:
        return str(value[0]).strip() or default
    if isinstance(value, str) and value.strip():
        return value.strip()
    return default


def to_number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def build_row(feature):
    properties = feature.get("properties") or {}
    geometry = feature.get("geometry") or {}
    coordinates = geometry.get("coordinates") or []
    key = str(feature.get("id", "")).strip()
    place = first_text(properties.get("place"), "")
    magnitude = to_number(properties.get("mag"))
    moment = to_number(properties.get("time"))
    depth = to_number(coordinates[2]) if len(coordinates) > 2 else None
    if not key or not place or magnitude is None or moment is None or depth is None:
        return None
    year = (EPOCH + timedelta(milliseconds=moment)).year
    if not 1900 <= year <= 2026:
        return None
    region = place.rsplit(",", 1)[-1].strip() or place
    return [
        key,
        place,
        region,
        year,
        round(magnitude, 2),
        round(depth, 2),
        int(properties.get("sig") or 0),
        int(properties.get("felt") or 0),
        int(properties.get("nst") or 0),
        first_text(properties.get("magType"), "unknown"),
        first_text(properties.get("net"), "unknown").upper(),
    ]


class ScrapeWorker(QThread):
    batch = pyqtSignal(list)
    status = pyqtSignal(str)
    completed = pyqtSignal(str)

    def __init__(self, existing_keys, target, source_url=""):
        super().__init__()
        self.seen = set(existing_keys)
        self.target = target
        self.source_url = source_url.strip()
        self.failures = 0
        self._stop_requested = False
        self._running = threading.Event()
        self._running.set()

    def pause(self):
        self._running.clear()

    def resume(self):
        self._running.set()

    def stop(self):
        self._stop_requested = True
        self._running.set()

    def run(self):
        session = requests.Session()
        session.headers.update({"User-Agent": USER_AGENT})
        try:
            reason = self._crawl(session)
        except Exception as error:
            reason = f"Stopped by an error: {error}"
        self.completed.emit(reason)

    def _query_plan(self):
        if self.source_url:
            return [("custom URL", validate_source_url(self.source_url), PAGES_PER_CUSTOM_URL)]
        return [
            (
                str(year),
                {"starttime": f"{year}-01-01", "endtime": f"{year + 1}-01-01", "minmagnitude": MIN_MAGNITUDE},
                PAGES_PER_YEAR,
            )
            for year in YEARS
        ]

    def _checkpoint(self):
        while not self._running.wait(0.2):
            if self._stop_requested:
                return False
        return not self._stop_requested

    def _crawl(self, session):
        for label, base, max_pages in self._query_plan():
            for page in range(1, max_pages + 1):
                if not self._checkpoint():
                    return "Collection stopped"
                if len(self.seen) >= self.target:
                    return "Target reached"
                self.status.emit(f"Collecting '{label}' - page {page}")
                documents = self._fetch(session, base, page)
                if documents is None:
                    self.failures += 1
                    if self.failures >= MAX_CONSECUTIVE_FAILURES:
                        return "Network problem: please check your internet connection and try again"
                    break
                self.failures = 0
                if not documents:
                    break
                rows = self._extract(documents)
                if rows:
                    self.batch.emit(rows)
                time.sleep(REQUEST_DELAY)
        if len(self.seen) >= self.target:
            return "Target reached"
        return "All sources finished before the target was reached"

    def _fetch(self, session, base, page):
        params = dict(base)
        params.update(
            {
                "format": "geojson",
                "orderby": "time",
                "limit": PAGE_SIZE,
                "offset": (page - 1) * PAGE_SIZE + 1,
            }
        )
        for attempt in range(4):
            if self._stop_requested:
                return []
            try:
                response = session.get(API_URL, params=params, timeout=REQUEST_TIMEOUT)
                if response.status_code == 200:
                    return response.json().get("features", [])
                if response.status_code in (429, 500, 502, 503, 504):
                    time.sleep(2 * (attempt + 1))
                    continue
                return []
            except (requests.RequestException, ValueError):
                time.sleep(2 * (attempt + 1))
        return None

    def _extract(self, documents):
        rows = []
        for document in documents:
            if len(self.seen) >= self.target:
                break
            row = build_row(document)
            if row is None or row[0] in self.seen:
                continue
            self.seen.add(row[0])
            rows.append(row)
        return rows
