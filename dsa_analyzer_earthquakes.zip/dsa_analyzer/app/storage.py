import csv

from .config import CSV_PATH, DATA_DIR
from .models import COLUMNS, parse_value


def load_earthquakes():
    if not CSV_PATH.exists():
        return []
    rows = []
    with CSV_PATH.open(newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        next(reader, None)
        for raw in reader:
            if len(raw) != len(COLUMNS):
                continue
            try:
                rows.append([parse_value(column.kind, value) for column, value in zip(COLUMNS, raw)])
            except ValueError:
                continue
    return rows


def save_earthquakes(rows):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temporary = CSV_PATH.with_suffix(".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([column.title for column in COLUMNS])
        writer.writerows(rows)
    temporary.replace(CSV_PATH)
