from PyQt6.QtCore import Qt
from PyQt6.QtGui import QBrush, QColor
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .filters import Condition, build_composite_predicate, operators_for
from .models import COLUMNS, TEXT
from .searching import SEARCH_ALGORITHMS, search_equals
from .sorting import ALGORITHMS, MULTI_LEVEL_ALGORITHMS
from .workers import BenchmarkWorker

BEST_COLOR = QColor(198, 239, 206)
RUNNING_COLOR = QColor(255, 242, 204)


def make_item(text, align_right=False):
    item = QTableWidgetItem(text)
    item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
    if align_right:
        item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    return item


def paint_row(table, row, color):
    for column in range(table.columnCount()):
        item = table.item(row, column)
        if item is not None:
            item.setBackground(QBrush(color))


class MultiSortDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Multi-Level Sort")
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Records are sorted by Level 1 first. Ties are broken by Level 2, then Level 3."))
        grid = QGridLayout()
        self.column_boxes = []
        self.order_boxes = []
        for level in range(3):
            column_box = QComboBox()
            if level > 0:
                column_box.addItem("(none)", -1)
            for index, column in enumerate(COLUMNS):
                column_box.addItem(column.title, index)
            order_box = QComboBox()
            order_box.addItems(["Ascending", "Descending"])
            grid.addWidget(QLabel(f"Level {level + 1}"), level, 0)
            grid.addWidget(column_box, level, 1)
            grid.addWidget(order_box, level, 2)
            self.column_boxes.append(column_box)
            self.order_boxes.append(order_box)
        self.column_boxes[0].setCurrentIndex(2)
        layout.addLayout(grid)
        algorithm_row = QHBoxLayout()
        algorithm_row.addWidget(QLabel("Algorithm (stable only)"))
        self.algorithm_box = QComboBox()
        self.algorithm_box.addItems(MULTI_LEVEL_ALGORITHMS)
        self.algorithm_box.setCurrentText("Merge Sort")
        algorithm_row.addWidget(self.algorithm_box, 1)
        layout.addLayout(algorithm_row)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def levels(self):
        result = []
        for column_box, order_box in zip(self.column_boxes, self.order_boxes):
            index = column_box.currentData()
            if index is not None and index >= 0:
                result.append((index, order_box.currentIndex() == 1))
        return result

    def algorithm_name(self):
        return self.algorithm_box.currentText()


class ConditionRow(QWidget):
    def __init__(self, on_remove):
        super().__init__()
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.connector = QComboBox()
        self.connector.addItems(["AND", "OR"])
        self.connector.setFixedWidth(70)
        self.negate = QCheckBox("NOT")
        self.column = QComboBox()
        for index, column in enumerate(COLUMNS):
            self.column.addItem(column.title, index)
        self.operator = QComboBox()
        self.value = QLineEdit()
        self.value.setPlaceholderText("Value")
        self.remove_button = QPushButton("Remove")
        self.remove_button.clicked.connect(lambda _checked=False: on_remove(self))
        self.column.currentIndexChanged.connect(self.refresh_operators)
        for widget in (self.connector, self.negate, self.column, self.operator):
            layout.addWidget(widget)
        layout.addWidget(self.value, 1)
        layout.addWidget(self.remove_button)
        self.refresh_operators()

    def refresh_operators(self):
        kind = COLUMNS[self.column.currentData()].kind
        self.operator.clear()
        self.operator.addItems(operators_for(kind))

    def condition(self):
        return Condition(
            self.column.currentData(),
            self.operator.currentText(),
            self.value.text(),
            self.negate.isChecked(),
        )


class CompositeFilterDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Advanced Filter (AND / OR / NOT)")
        self.setMinimumWidth(820)
        self.predicate = None
        self.rows = []
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Combine conditions with AND / OR and tick NOT to negate a condition. AND is evaluated before OR."))
        self.rows_layout = QVBoxLayout()
        layout.addLayout(self.rows_layout)
        add_button = QPushButton("Add Condition")
        add_button.clicked.connect(lambda _checked=False: self.add_row())
        layout.addWidget(add_button, alignment=Qt.AlignmentFlag.AlignLeft)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Apply Filter")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.add_row()
        self.add_row()

    def add_row(self):
        row = ConditionRow(self.remove_row)
        self.rows.append(row)
        self.rows_layout.addWidget(row)
        self.refresh_connectors()

    def remove_row(self, row):
        if len(self.rows) == 1:
            return
        self.rows.remove(row)
        self.rows_layout.removeWidget(row)
        row.deleteLater()
        self.refresh_connectors()

    def refresh_connectors(self):
        for position, row in enumerate(self.rows):
            row.connector.setVisible(position > 0)

    def accept(self):
        conditions = [row.condition() for row in self.rows]
        connectors = [row.connector.currentText() for row in self.rows[1:]]
        try:
            self.predicate = build_composite_predicate(conditions, connectors)
        except ValueError as error:
            QMessageBox.warning(self, "Invalid filter", str(error))
            return
        super().accept()


class BenchmarkDialog(QDialog):
    HEADERS = ["Algorithm", "Time Complexity", "Stable", "Time (ms)", "Comparisons", "Swaps / Moves", "Status"]

    def __init__(self, parent, rows, column_index):
        super().__init__(parent)
        self.setWindowTitle("Sorting Benchmark - All Algorithms")
        self.resize(1050, 520)
        self.entries = {}
        self.completed = 0
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Column: {COLUMNS[column_index].title}   |   Records: {len(rows):,}   |   Order: ascending"))
        self.table = QTableWidget(len(ALGORITHMS), len(self.HEADERS))
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.row_of = {}
        for position, algorithm in enumerate(ALGORITHMS):
            self.row_of[algorithm.name] = position
            values = [algorithm.name, algorithm.complexity, "Yes" if algorithm.stable else "No", "-", "-", "-", "Waiting"]
            for column, value in enumerate(values):
                self.table.setItem(position, column, make_item(value, align_right=column in (3, 4, 5)))
        layout.addWidget(self.table, 1)
        self.progress = QProgressBar()
        self.progress.setMaximum(len(ALGORITHMS))
        layout.addWidget(self.progress)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.stop_button = QPushButton("Stop After Current Algorithm")
        self.stop_button.clicked.connect(lambda _checked=False: self.worker.cancel())
        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.close)
        buttons.addWidget(self.stop_button)
        buttons.addWidget(self.close_button)
        layout.addLayout(buttons)
        self.worker = BenchmarkWorker(rows, column_index)
        self.worker.algorithm_started.connect(self.on_started)
        self.worker.entry_ready.connect(self.on_entry)
        self.worker.all_done.connect(self.on_done)
        self.worker.start()

    def on_started(self, name):
        row = self.row_of[name]
        self.table.item(row, 6).setText("Running...")
        paint_row(self.table, row, RUNNING_COLOR)

    def on_entry(self, entry):
        row = self.row_of[entry.name]
        self.entries[entry.name] = entry
        ok = entry.status == "Done"
        self.table.item(row, 3).setText(f"{entry.elapsed_ms:,.3f}" if ok else "-")
        self.table.item(row, 4).setText(f"{entry.comparisons:,}" if ok else "-")
        self.table.item(row, 5).setText(f"{entry.swaps:,}" if ok else "-")
        self.table.item(row, 6).setText(entry.status)
        paint_row(self.table, row, QColor(255, 255, 255))
        self.completed += 1
        self.progress.setValue(self.completed)

    def on_done(self):
        self.stop_button.setEnabled(False)
        finished = [entry for entry in self.entries.values() if entry.status == "Done"]
        if finished:
            best = min(finished, key=lambda entry: entry.elapsed_ms)
            paint_row(self.table, self.row_of[best.name], BEST_COLOR)
            self.table.item(self.row_of[best.name], 6).setText("Done - fastest")

    def done(self, result):
        self.worker.cancel()
        self.worker.wait()
        super().done(result)


class SearchCompareDialog(QDialog):
    HEADERS = ["Algorithm", "Time Complexity", "Needs Sorted Data", "Time (ms)", "Comparisons", "Matches", "Status"]

    def __init__(self, parent, rows, column_index, target):
        super().__init__(parent)
        self.setWindowTitle("Search Comparison - All Algorithms")
        self.resize(1000, 380)
        kind = COLUMNS[column_index].kind
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Column: {COLUMNS[column_index].title}   |   Operator: equals   |   Value: {target}"))
        table = QTableWidget(len(SEARCH_ALGORITHMS), len(self.HEADERS))
        table.setHorizontalHeaderLabels(self.HEADERS)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(table)
        timings = {}
        for position, algorithm in enumerate(SEARCH_ALGORITHMS):
            values = [algorithm.name, algorithm.complexity, "Yes" if algorithm.needs_sorted else "No", "-", "-", "-", ""]
            if algorithm.numeric_only and kind == TEXT:
                values[6] = "Numeric columns only"
            else:
                try:
                    result = search_equals(algorithm.name, rows, column_index, kind, target)
                    values[3] = f"{result.elapsed_ms:,.3f}"
                    values[4] = f"{result.comparisons:,}"
                    values[5] = f"{len(result.rows):,}"
                    values[6] = "Done"
                    timings[position] = result.elapsed_ms
                except ValueError as error:
                    values[6] = str(error)
            for column, value in enumerate(values):
                table.setItem(position, column, make_item(value, align_right=column in (3, 4, 5)))
        if timings:
            paint_row(table, min(timings, key=timings.get), BEST_COLOR)
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        layout.addWidget(close_button, alignment=Qt.AlignmentFlag.AlignRight)
