import random
from dataclasses import dataclass

from .models import COLUMNS, TEXT
from .sorting import ALGORITHMS, sort_rows


@dataclass
class BenchmarkEntry:
    name: str
    complexity: str
    stable: bool
    status: str
    elapsed_ms: float = 0.0
    comparisons: int = 0
    swaps: int = 0


def select_rows(rows, size):
    if not size or size >= len(rows):
        return list(rows)
    return random.Random(42).sample(rows, size)


def run_benchmark(rows, column_index, on_start, on_entry, is_cancelled):
    kind = COLUMNS[column_index].kind
    for algorithm in ALGORITHMS:
        if is_cancelled():
            break
        on_start(algorithm.name)
        if algorithm.numeric_only and kind == TEXT:
            on_entry(BenchmarkEntry(algorithm.name, algorithm.complexity, algorithm.stable, "Numeric columns only"))
            continue
        try:
            result = sort_rows(algorithm.name, rows, column_index)
        except ValueError as error:
            on_entry(BenchmarkEntry(algorithm.name, algorithm.complexity, algorithm.stable, str(error)))
            continue
        on_entry(
            BenchmarkEntry(
                algorithm.name,
                algorithm.complexity,
                algorithm.stable,
                "Done",
                result.elapsed_ms,
                result.comparisons,
                result.swaps,
            )
        )
