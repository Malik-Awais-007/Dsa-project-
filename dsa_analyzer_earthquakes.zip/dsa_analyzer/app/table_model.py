from PyQt6.QtCore import QAbstractTableModel, QModelIndex, Qt

from .models import COLUMNS, FLOAT


class EarthquakeTableModel(QAbstractTableModel):
    def __init__(self):
        super().__init__()
        self.all_rows = []
        self.view_rows = []
        self.predicate = None

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.view_rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(COLUMNS)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        column = COLUMNS[index.column()]
        if role == Qt.ItemDataRole.DisplayRole:
            value = self.view_rows[index.row()][index.column()]
            if column.kind == FLOAT:
                return f"{value:.2f}"
            return str(value)
        if role == Qt.ItemDataRole.TextAlignmentRole and column.numeric:
            return Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            return COLUMNS[section].title
        return str(section + 1)

    def _rebuild(self):
        if self.predicate is None:
            self.view_rows = list(self.all_rows)
        else:
            self.view_rows = [row for row in self.all_rows if self.predicate(row)]

    def set_rows(self, rows):
        self.beginResetModel()
        self.all_rows = rows
        self._rebuild()
        self.endResetModel()

    def append_rows(self, rows):
        self.all_rows.extend(rows)
        matched = rows if self.predicate is None else [row for row in rows if self.predicate(row)]
        if not matched:
            return
        first = len(self.view_rows)
        self.beginInsertRows(QModelIndex(), first, first + len(matched) - 1)
        self.view_rows.extend(matched)
        self.endInsertRows()

    def apply_filter(self, predicate):
        self.beginResetModel()
        self.predicate = predicate
        self._rebuild()
        self.endResetModel()

    def replace_all_rows(self, rows):
        self.beginResetModel()
        self.all_rows = rows
        self._rebuild()
        self.endResetModel()

    def replace_view_rows(self, rows):
        self.beginResetModel()
        self.view_rows = rows
        self.endResetModel()
