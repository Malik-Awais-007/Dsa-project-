from dataclasses import dataclass

from .models import COLUMNS, TEXT, parse_number

TEXT_OPERATORS = ["contains", "does not contain", "starts with", "ends with", "equals", "not equals"]
NUMBER_OPERATORS = ["equals", "not equals", "greater than", "greater or equal", "less than", "less or equal"]


@dataclass
class Condition:
    column_index: int
    operator: str
    value: str
    negate: bool = False


def operators_for(kind):
    return TEXT_OPERATORS if kind == TEXT else NUMBER_OPERATORS


def make_predicate(column_index, kind, operator, raw_value):
    if kind == TEXT:
        needle = raw_value.strip().casefold()
        if not needle:
            raise ValueError("Please enter a value")
        tests = {
            "contains": lambda value: needle in value,
            "does not contain": lambda value: needle not in value,
            "starts with": lambda value: value.startswith(needle),
            "ends with": lambda value: value.endswith(needle),
            "equals": lambda value: value == needle,
            "not equals": lambda value: value != needle,
        }
        test = tests[operator]
        return lambda row: test(row[column_index].casefold())
    number = parse_number(kind, raw_value)
    tests = {
        "equals": lambda value: value == number,
        "not equals": lambda value: value != number,
        "greater than": lambda value: value > number,
        "greater or equal": lambda value: value >= number,
        "less than": lambda value: value < number,
        "less or equal": lambda value: value <= number,
    }
    test = tests[operator]
    return lambda row: test(row[column_index])


def compile_condition(condition):
    base = make_predicate(
        condition.column_index,
        COLUMNS[condition.column_index].kind,
        condition.operator,
        condition.value,
    )
    if condition.negate:
        return lambda row: not base(row)
    return base


def build_composite_predicate(conditions, connectors):
    if not conditions:
        raise ValueError("Add at least one condition")
    groups = [[]]
    for position, condition in enumerate(conditions):
        if position > 0 and connectors[position - 1] == "OR":
            groups.append([])
        groups[-1].append(compile_condition(condition))
    return lambda row: any(all(test(row) for test in group) for group in groups)


def make_id_predicate(rows):
    identifiers = {id(row) for row in rows}
    return lambda row: id(row) in identifiers
